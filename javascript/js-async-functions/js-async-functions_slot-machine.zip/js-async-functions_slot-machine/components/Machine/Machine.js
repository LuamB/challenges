export function Machine() {
  const machineElement = document.createElement("div");
  machineElement.classList.add("machine");

  return machineElement;
}
